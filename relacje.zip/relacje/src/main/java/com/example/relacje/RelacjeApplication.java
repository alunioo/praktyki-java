package com.example.relacje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelacjeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelacjeApplication.class, args);
	}

}
